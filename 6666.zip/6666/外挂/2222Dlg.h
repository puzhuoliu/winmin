// 2222Dlg.h : header file
//
#define MINE_ROWS_COUNT    26                              //�������
#define MINE_COLS_COUNT    32                              //�������

#define MINE_WINDOW_CLASS  TEXT("ɨ��")                    //ɨ�״�������
#define MINE_WINDOW_TITLE  TEXT("ɨ��")                    //ɨ�״��ڱ���

#define MINE_DATA_ADDR     0x01005340                      //�������׵�ַ

#define MINE_FLAG_BORDER   0x10                            //�߽��־
#define MINE_FLAG_HASMINE  0x8f                            //����
#define MINE_FLAG_NOMINE   0x0f                            //����

#if !defined(AFX_2222DLG_H__CBC56076_320A_4710_B3E0_FBF159D47429__INCLUDED_)
#define AFX_2222DLG_H__CBC56076_320A_4710_B3E0_FBF159D47429__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CMy2222Dlg dialog

class CMy2222Dlg : public CDialog
{
// Construction
public:
	BOOL GetMineSize();
	HANDLE GetMineProc();
	CMy2222Dlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CMy2222Dlg)
	enum { IDD = IDD_MY2222_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy2222Dlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CMy2222Dlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButton1();
	afx_msg void OnButton2();
	afx_msg void OnButton3();
	afx_msg void OnButton4();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BYTE bMines[MINE_ROWS_COUNT][MINE_COLS_COUNT];
	DWORD dwMineProcId;
	HANDLE hMineProc;
	HWND hMineWnd;
	DWORD RowsCount;
	DWORD ColsCount;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_2222DLG_H__CBC56076_320A_4710_B3E0_FBF159D47429__INCLUDED_)
