// 2222.h : main header file for the 2222 application
//

#if !defined(AFX_2222_H__C347CA60_78B1_4920_9F46_2787324E426C__INCLUDED_)
#define AFX_2222_H__C347CA60_78B1_4920_9F46_2787324E426C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMy2222App:
// See 2222.cpp for the implementation of this class
//

class CMy2222App : public CWinApp
{
public:
	CMy2222App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMy2222App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMy2222App)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_2222_H__C347CA60_78B1_4920_9F46_2787324E426C__INCLUDED_)
